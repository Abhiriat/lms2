import React, { useState, useRef } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Button,
  TextField,
  Box,
  Typography,
  Chip,
  Paper,
  LinearProgress,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  Checkbox,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  CircularProgress,
  Backdrop
} from '@mui/material';
import { Icon } from '@iconify/react';
import audio from '../lms/audio.mp3';

export function LMSView() {
  const [answers, setAnswers] = useState({
    trueFalse: {},
    blanks: {},
    multipleChoice: {},
    checkboxes: {},
  });
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false); // New: loading state
  const [progress, setProgress] = useState(0); // New: progress value
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const exerciseData = {
    title: 'Business Meeting Discussion',
    level: 'Intermediate',
    duration: '3:45',
    topic: 'Professional Communication',
    audioUrl: audio,
    description: 'Listen to a conversation between colleagues discussing a new project proposal.',
  };

 const questions = {
  trueFalse: [
    { id: 1, question: 'The meeting is about a marketing campaign.' },
    { id: 2, question: 'The deadline for the project is next month.' },
    { id: 3, question: 'Three people are speaking in the conversation.' },
    { id: 4, question: 'The team has already received approval from upper management.' },
    { id: 5, question: 'The product launch will take place internationally from the start.' },
    { id: 6, question: 'Everyone in the meeting agrees on the proposed timeline.' },
    { id: 7, question: 'Remote team members will join via video call for future meetings.' },
  ],

  blanks: [
    { id: 1, question: 'The project budget is approximately _____ dollars.' },
    { id: 2, question: 'The team leader\'s name is _____.' },
    { id: 3, question: 'They plan to complete the first phase by _____.' },
    { id: 4, question: 'The official product launch date is set for _____.' },
    { id: 5, question: 'The main target audience is _____.' },
    { id: 6, question: 'The marketing team will collaborate with the _____ department for social media content.' },
    { id: 7, question: 'The project code name mentioned is "Project _____".' },
  ],

  multipleChoice: [
    {
      id: 1,
      question: 'What is the main purpose of the meeting?',
      options: ['Budget review', 'Project planning', 'Team building', 'Performance evaluation'],
    },
    {
      id: 2,
      question: 'How many team members will work on this project?',
      options: ['3-4 members', '5-6 members', '7-8 members', '9-10 members'],
    },
    {
      id: 3,
      question: 'Which platform will be the primary focus for the digital advertising campaign?',
      options: ['Facebook only', 'Instagram and TikTok', 'Google Ads and YouTube', 'LinkedIn and Twitter'],
    },
    {
      id: 4,
      question: 'Who is responsible for creating the final presentation for the stakeholders?',
      options: ['Sarah', 'Michael', 'The marketing team as a whole', 'An external agency'],
    },
    {
      id: 5,
      question: 'What is the biggest concern raised about the current timeline?',
      options: ['Too expensive', 'Too aggressive', 'Not ambitious enough', 'No concerns were raised'],
    },
  ],

  checkboxes: [
    {
      id: 1,
      question: 'Which topics were discussed in the meeting? (Select all that apply)',
      options: [
        'Timeline',
        'Budget',
        'Team assignments',
        'Client feedback',
        'Marketing strategy',
        'Product features',
        'Risk assessment',
        'Competitor analysis',
        'Content calendar',
        'Key performance indicators (KPIs)',
      ],
    },
    {
      id: 2,
      question: 'Which tools or platforms were mentioned for project management and collaboration? (Select all that apply)',
      options: ['Slack', 'Microsoft Teams', 'Trello', 'Asana', 'Google Workspace', 'Notion', 'Jira', 'Zoom'],
    },
  ],
};

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleSeek = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = (parseFloat(event.target.value) / 100) * duration;
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleTrueFalseChange = (questionId: number, value: string) => {
    setAnswers(prev => ({
      ...prev,
      trueFalse: { ...prev.trueFalse, [questionId]: value }
    }));
  };

  const handleBlankChange = (questionId: number, value: string) => {
    setAnswers(prev => ({
      ...prev,
      blanks: { ...prev.blanks, [questionId]: value }
    }));
  };

  const handleMultipleChoiceChange = (questionId: number, value: string) => {
    setAnswers(prev => ({
      ...prev,
      multipleChoice: { ...prev.multipleChoice, [questionId]: value }
    }));
  };

  const handleCheckboxChange = (questionId: number, option: string) => {
    setAnswers(prev => {
      const current = prev.checkboxes[questionId] || [];
      const newValue = current.includes(option)
        ? current.filter(item => item !== option)
        : [...current, option];
      return {
        ...prev,
        checkboxes: { ...prev.checkboxes, [questionId]: newValue }
      };
    });
  };

  const calculateProgress = () => {
    const totalQuestions =
      questions.trueFalse.length +
      questions.blanks.length +
      questions.multipleChoice.length +
      questions.checkboxes.length;

    const answeredQuestions =
      Object.keys(answers.trueFalse).length +
      Object.keys(answers.blanks).length +
      Object.keys(answers.multipleChoice).length +
      Object.keys(answers.checkboxes).length;

    return Math.round((answeredQuestions / totalQuestions) * 100);
  };

  // New: Handle Analyze with 5-second loader
  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setProgress(0);
    setShowAnalysis(false);

    const duration = 5000; // 5 seconds
    const interval = 50;
    const increment = (100 * interval) / duration;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setIsAnalyzing(false);
          setShowAnalysis(true);
          return 100;
        }
        return Math.min(prev + increment, 100);
      });
    }, interval);
  };

  const handleCloseAnalysis = () => {
    setShowAnalysis(false);
  };

  const getDummyAnalysis = () => {
    return {
      overallScore: 78,
      listeningAccuracy: 85,
      comprehension: 75,
      vocabulary: 80,
      sections: [
        { name: 'True/False', score: 100, answered: 3, total: 3 },
        { name: 'Fill in the Blanks', score: 67, answered: 3, total: 3 },
        { name: 'Multiple Choice', score: 75, answered: 2, total: 2 },
        { name: 'Multiple Selection', score: 60, answered: 1, total: 1 },
      ],
      strengths: ['Good attention to detail', 'Strong vocabulary recognition'],
      improvements: ['Work on understanding context clues', 'Practice with longer audio segments'],
      timeSpent: '8 minutes 23 seconds',
      replays: 3,
    };
  };

  const analysis = getDummyAnalysis();

  return (
    <Box sx={{ backgroundColor: '#f5f7fa', minHeight: '100vh', py: 3 }}>
      <Container maxWidth="xl">
        {/* Header */}
        <Box sx={{ mb: 4, backgroundColor: '#1e3a8a', color: 'white', p: 3, borderRadius: 2 }}>
          <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 1 }}>
            English Listening Practice
          </Typography>
          <Typography variant="body1" sx={{ mb: 2 }}>
            {exerciseData.description}
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Chip label={`Level: ${exerciseData.level}`} sx={{ backgroundColor: '#a78bfa', color: 'white' }} />
            <Chip label={`Duration: ${exerciseData.duration}`} sx={{ backgroundColor: '#a78bfa', color: 'white' }} />
            <Chip label={`Topic: ${exerciseData.topic}`} sx={{ backgroundColor: '#a78bfa', color: 'white' }} />
          </Box>
        </Box>

        <Grid container spacing={3}>
          {/* Left Side - Audio Player & Questions */}
          <Grid item xs={12} md={8} sx={{width:{xs:'100%',md:'50%'}}}>
            {/* Audio Player Card */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader title={exerciseData.title} sx={{ fontWeight: 'bold' }} />
              <CardContent>
                <Paper sx={{ p: 3, backgroundColor: '#f8f9fa', borderRadius: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                    <Button
                      onClick={handlePlayPause}
                      variant="contained"
                      sx={{ 
                        minWidth: 60, 
                        height: 60, 
                        borderRadius: '50%',
                        backgroundColor: '#1e3a8a',
                        '&:hover': { backgroundColor: '#6d28d9' }
                      }}
                    >
                      <Icon icon={isPlaying ? 'mdi:pause' : 'mdi:play'} width={32} height={32} />
                    </Button>
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="caption">{formatTime(currentTime)}</Typography>
                        <Typography variant="caption">{formatTime(duration)}</Typography>
                      </Box>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={duration ? (currentTime / duration) * 100 : 0}
                        onChange={handleSeek}
                        style={{
                          width: '100%',
                          height: 8,
                          borderRadius: 4,
                          outline: 'none',
                          cursor: 'pointer',
                        }}
                      />
                    </Box>
                  </Box>
                  <audio
                    ref={audioRef}
                    src={exerciseData.audioUrl}
                    onTimeUpdate={handleTimeUpdate}
                    onLoadedMetadata={handleLoadedMetadata}
                    onEnded={() => setIsPlaying(false)}
                  />
                  <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center', mt: 2 }}>
                    <Chip 
                      icon={<Icon icon="mdi:headphones" width={20} />}
                      label="Focus Mode" 
                      size="small"
                      sx={{ backgroundColor: '#e9d5ff' }}
                    />
                    <Chip 
                      icon={<Icon icon="mdi:subtitles" width={20} />}
                      label="Transcript Available" 
                      size="small"
                      sx={{ backgroundColor: '#e9d5ff' }}
                    />
                  </Box>
                </Paper>
              </CardContent>
            </Card>

            {/* True/False Questions */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader 
                title="Section 1: True or False" 
                sx={{ fontWeight: 'bold', backgroundColor: '#fef3c7' }}
              />
              <CardContent>
                {questions.trueFalse.map((q) => (
                  <Paper key={q.id} sx={{ p: 2, mb: 2, border: '1px solid #e5e7eb' }}>
                    <Typography variant="body1" sx={{ mb: 2, fontWeight: 'medium' }}>
                      {q.id}. {q.question}
                    </Typography>
                    <FormControl component="fieldset">
                      <RadioGroup
                        row
                        value={answers.trueFalse[q.id] || ''}
                        onChange={(e) => handleTrueFalseChange(q.id, e.target.value)}
                      >
                        <FormControlLabel value="true" control={<Radio />} label="True" />
                        <FormControlLabel value="false" control={<Radio />} label="False" />
                      </RadioGroup>
                    </FormControl>
                  </Paper>
                ))}
              </CardContent>
            </Card>

            {/* Fill in the Blanks */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader 
                title="Section 2: Fill in the Blanks" 
                sx={{ fontWeight: 'bold', backgroundColor: '#dbeafe' }}
              />
              <CardContent>
                {questions.blanks.map((q) => (
                  <Paper key={q.id} sx={{ p: 2, mb: 2, border: '1px solid #e5e7eb' }}>
                    <Typography variant="body1" sx={{ mb: 2, fontWeight: 'medium' }}>
                      {q.id}. {q.question}
                    </Typography>
                    <TextField
                      fullWidth
                      variant="outlined"
                      size="small"
                      value={answers.blanks[q.id] || ''}
                      onChange={(e) => handleBlankChange(q.id, e.target.value)}
                      placeholder="Type your answer here..."
                    />
                  </Paper>
                ))}
              </CardContent>
            </Card>

            {/* Multiple Choice */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader 
                title="Section 3: Multiple Choice" 
                sx={{ fontWeight: 'bold', backgroundColor: '#dcfce7' }}
              />
              <CardContent>
                {questions.multipleChoice.map((q) => (
                  <Paper key={q.id} sx={{ p: 2, mb: 2, border: '1px solid #e5e7eb' }}>
                    <Typography variant="body1" sx={{ mb: 2, fontWeight: 'medium' }}>
                      {q.id}. {q.question}
                    </Typography>
                    <FormControl component="fieldset" fullWidth>
                      <RadioGroup
                        value={answers.multipleChoice[q.id] || ''}
                        onChange={(e) => handleMultipleChoiceChange(q.id, e.target.value)}
                      >
                        {q.options.map((option, idx) => (
                          <FormControlLabel
                            key={idx}
                            value={option}
                            control={<Radio />}
                            label={option}
                          />
                        ))}
                      </RadioGroup>
                    </FormControl>
                  </Paper>
                ))}
              </CardContent>
            </Card>

            {/* Checkboxes */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader 
                title="Section 4: Multiple Selection" 
                sx={{ fontWeight: 'bold', backgroundColor: '#fce7f3' }}
              />
              <CardContent>
                {questions.checkboxes.map((q) => (
                  <Paper key={q.id} sx={{ p: 2, mb: 2, border: '1px solid #e5e7eb' }}>
                    <Typography variant="body1" sx={{ mb: 2, fontWeight: 'medium' }}>
                      {q.id}. {q.question}
                    </Typography>
                    <FormControl component="fieldset" fullWidth>
                      {q.options.map((option, idx) => (
                        <FormControlLabel
                          key={idx}
                          control={
                            <Checkbox
                              checked={(answers.checkboxes[q.id] || []).includes(option)}
                              onChange={() => handleCheckboxChange(q.id, option)}
                            />
                          }
                          label={option}
                        />
                      ))}
                    </FormControl>
                  </Paper>
                ))}
              </CardContent>
            </Card>

             {/* Analyze Button with Loader */}
                       <Box sx={{ position: 'relative' }}>
                         <Button
                           variant="contained"
                           size="large"
                           fullWidth
                           onClick={handleAnalyze}
                           disabled={isAnalyzing}
                           sx={{
                             backgroundColor: '#1e3a8a',
                             py: 2,
                             fontSize: '1.1rem',
                             fontWeight: 'bold',
                             '&:hover': { backgroundColor: '#6d28d9' },
                             '&.Mui-disabled': { backgroundColor: '#93c5fd' }
                           }}
                           startIcon={isAnalyzing ? <CircularProgress size={24} color="inherit" /> : <Icon icon="mdi:chart-bar" width={24} />}
                         >
                           {isAnalyzing ? 'Analyzing Your Answers...' : 'Analyze My Practice'}
                         </Button>
           
                         {/* Progress Bar Below Button */}
                      <Backdrop
  sx={{ 
    color: '#fff', 
    zIndex: (theme) => theme.zIndex.modal + 1,
    flexDirection: 'column',
    gap: 2
  }}
  open={isAnalyzing}
>
  <CircularProgress size={68} thickness={4.5} />
  <Typography variant="h5" fontWeight="bold">
    Analyzing Your Answers...
  </Typography>
  <Typography variant="body2">
    Evaluating listening comprehension and accuracy
  </Typography>
</Backdrop>
                       </Box>
          </Grid>

          {/* Right Side - Progress & Tips */}
          <Grid item xs={12} md={4} sx={{width:{xs:'100%',md:'40%'}}}>
            {/* Progress Card */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader title="Your Progress" sx={{ fontWeight: 'bold' }} />
              <CardContent>
                <Box sx={{ mb: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#1e3a8a' }}>
                      {calculateProgress()}%
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Complete
                    </Typography>
                  </Box>
                  <LinearProgress
                    variant="determinate"
                    value={calculateProgress()}
                    sx={{ 
                      height: 12, 
                      borderRadius: 6,
                      backgroundColor: '#e9d5ff',
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: '#1e3a8a'
                      }
                    }}
                  />
                  <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                    Keep going! Complete all sections for detailed analysis.
                  </Typography>
                </Box>

                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#fef3c7' }}>
                      <Icon icon="mdi:check-circle" color="#eab308" width={28} />
                      <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                        {Object.keys(answers.trueFalse).length + 
                         Object.keys(answers.blanks).length + 
                         Object.keys(answers.multipleChoice).length + 
                         Object.keys(answers.checkboxes).length}
                      </Typography>
                      <Typography variant="caption">Answered</Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#dbeafe' }}>
                      <Icon icon="mdi:playlist-check" color="#3b82f6" width={28} />
                      <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                        {questions.trueFalse.length + 
                         questions.blanks.length + 
                         questions.multipleChoice.length + 
                         questions.checkboxes.length}
                      </Typography>
                      <Typography variant="caption">Total Questions</Typography>
                    </Paper>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>

            {/* Listening Tips Card */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)', mb: 3 }}>
              <CardHeader title="Listening Tips" sx={{ fontWeight: 'bold' }} />
              <CardContent>
                {[
                  { icon: 'mdi:lightbulb', text: 'Listen to the audio at least twice before answering' },
                  { icon: 'mdi:pencil', text: 'Take notes while listening to key information' },
                  { icon: 'mdi:focus-field', text: 'Pay attention to tone and context clues' },
                  { icon: 'mdi:repeat', text: 'Use the replay function for difficult sections' },
                ].map((tip, idx) => (
                  <Paper key={idx} sx={{ p: 2, mb: 2, backgroundColor: '#f0f9ff', border: '1px solid #bae6fd' }}>
                    <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                      <Icon icon={tip.icon} color="#0284c7" width={24} />
                      <Typography variant="body2">{tip.text}</Typography>
                    </Box>
                  </Paper>
                ))}
              </CardContent>
            </Card>

            {/* Study Resources */}
            <Card sx={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}>
              <CardHeader title="Study Resources" sx={{ fontWeight: 'bold' }} />
              <CardContent>
                {[
                  { name: 'Audio Transcript', icon: 'mdi:file-document', color: '#ef4444' },
                  { name: 'Vocabulary List', icon: 'mdi:book-open', color: '#3b82f6' },
                  { name: 'Grammar Notes', icon: 'mdi:text-box', color: '#10b981' },
                ].map((resource, idx) => (
                  <Paper 
                    key={idx} 
                    sx={{ 
                      p: 2, 
                      mb: 2, 
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      '&:hover': { 
                        transform: 'translateX(4px)',
                        backgroundColor: '#f9fafb'
                      }
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Icon icon={resource.icon} color={resource.color} width={28} />
                      <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                        {resource.name}
                      </Typography>
                    </Box>
                  </Paper>
                ))}
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Analysis Dialog */}
        <Dialog 
          open={showAnalysis} 
          onClose={handleCloseAnalysis}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle sx={{ backgroundColor: '#1e3a8a', color: 'white', fontWeight: 'bold' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <Icon icon="mdi:chart-box" width={32} />
              Your Practice Analysis
            </Box>
          </DialogTitle>
          <DialogContent sx={{ mt: 3 }}>
            {/* Overall Score */}
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <Typography variant="h2" sx={{ fontWeight: 'bold', color: '#1e3a8a' }}>
                {analysis.overallScore}%
              </Typography>
              <Typography variant="h6" color="text.secondary">Overall Score</Typography>
            </Box>

            <Divider sx={{ mb: 3 }} />

            {/* Performance Metrics */}
            <Grid container spacing={3} sx={{ mb: 3 }}>
              <Grid item xs={4}>
                <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#fef3c7' }}>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>{analysis.listeningAccuracy}%</Typography>
                  <Typography variant="caption">Listening Accuracy</Typography>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#dbeafe' }}>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>{analysis.comprehension}%</Typography>
                  <Typography variant="caption">Comprehension</Typography>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ p: 2, textAlign: 'center', backgroundColor: '#dcfce7' }}>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>{analysis.vocabulary}%</Typography>
                  <Typography variant="caption">Vocabulary</Typography>
                </Paper>
              </Grid>
            </Grid>

            {/* Section Breakdown */}
            <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 2 }}>Section Performance</Typography>
            {analysis.sections.map((section, idx) => (
              <Box key={idx} sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">{section.name}</Typography>
                  <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                    {section.score}% ({section.answered}/{section.total})
                  </Typography>
                </Box>
                <LinearProgress 
                  variant="determinate" 
                  value={section.score}
                  sx={{ 
                    height: 8, 
                    borderRadius: 4,
                    backgroundColor: '#e5e7eb',
                    '& .MuiLinearProgress-bar': {
                      backgroundColor: section.score >= 80 ? '#10b981' : section.score >= 60 ? '#eab308' : '#ef4444'
                    }
                  }}
                />
              </Box>
            ))}

            <Divider sx={{ my: 3 }} />

            {/* Strengths & Improvements */}
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2, color: '#10b981' }}>
                  <Icon icon="mdi:check-circle" width={20} /> Strengths
                </Typography>
                {analysis.strengths.map((strength, idx) => (
                  <Paper key={idx} sx={{ p: 1.5, mb: 1, backgroundColor: '#f0fdf4', border: '1px solid #86efac' }}>
                    <Typography variant="body2">{strength}</Typography>
                  </Paper>
                ))}
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold', mb: 2, color: '#f59e0b' }}>
                  <Icon icon="mdi:lightbulb" width={20} /> Areas to Improve
                </Typography>
                {analysis.improvements.map((improvement, idx) => (
                  <Paper key={idx} sx={{ p: 1.5, mb: 1, backgroundColor: '#fffbeb', border: '1px solid #fde68a' }}>
                    <Typography variant="body2">{improvement}</Typography>
                  </Paper>
                ))}
              </Grid>
            </Grid>

            <Divider sx={{ my: 3 }} />

            {/* Practice Stats */}
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Icon icon="mdi:clock" color="#6b7280" width={20} />
                  <Typography variant="body2">
                    Time: <strong>{analysis.timeSpent}</strong>
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={6}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Icon icon="mdi:replay" color="#6b7280" width={20} />
                  <Typography variant="body2">
                    Replays: <strong>{analysis.replays}</strong>
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={handleCloseAnalysis} variant="outlined">
              Close
            </Button>
            <Button 
              variant="contained" 
              sx={{ backgroundColor: '#1e3a8a', '&:hover': { backgroundColor: '#6d28d9' } }}
              startIcon={<Icon icon="mdi:download" />}
            >
              Download Report
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
}